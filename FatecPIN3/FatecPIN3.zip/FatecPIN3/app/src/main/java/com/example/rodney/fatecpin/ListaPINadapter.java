package com.example.rodney.fatecpin;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import com.example.rodney.fatecpin.Modelos.PINS;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * Created by Rodney on 22/11/2017.
 */

public class ListaPINadapter extends RecyclerView.Adapter<ListaPINadapter.ViewHolder>{

    private ArrayList<PINS> dataset;
    private Context context;

    public ListaPINadapter(Context context) throws ParseException {
        this.context = context;
        dataset = new ArrayList<>();
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_pin, parent, false);

        return new ViewHolder(view);
    }


    


    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        PINS p = dataset.get(position);
        String datacorreta = p.getData();
        DateFormat df1 = new SimpleDateFormat("dd-MM-yyyy");



        Date result1 = null;
        try {
            result1 = df1.parse(datacorreta);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        //coloquei aqui no setText as 3 variáveis com datas, não sei o motivo, mas o parse ta cagando com a data, to tentando arrumar ainda
        holder.nomeTextView.setText("\n" + p.getDescricao() + "\n" + p.getData() + "\n" + datacorreta + "\n" + result1 + "\n");






    }

    @Override
    public int getItemCount() {
        return dataset.size();
    }

    public void adicionarListaPIN(ArrayList<PINS> listaPIN){
        dataset.addAll(listaPIN);
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private TextView nomeTextView;


        public ViewHolder(View itemView){
            super(itemView);

            nomeTextView = (TextView) itemView.findViewById(R.id.nomeTextView);

        }
    }


}
