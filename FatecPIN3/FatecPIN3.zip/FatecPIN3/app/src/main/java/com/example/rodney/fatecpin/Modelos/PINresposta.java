package com.example.rodney.fatecpin.Modelos;

import java.util.ArrayList;

/**
 * Created by Rodney on 22/11/2017.
 */

public class PINresposta {
    private ArrayList<PINS> pins;

    public ArrayList<PINS> getResults() {
        return pins;
    }

    public void setResults(ArrayList<PINS> pins) {
        this.pins = pins;
    }
}
